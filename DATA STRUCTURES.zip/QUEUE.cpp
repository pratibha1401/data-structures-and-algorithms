#include<iostream>
using namespace std;
int q[100],n=100,front=-1,rear=-1;
void insert()
{
	int val;
	if(rear == n-1)
	{
	cout<<"QUEUE OVERFLOW !"<<endl; 
	}
	else 
	{
		if(front == -1)
		{
		front=0;
	    }
		cout<<"ENTRE THE VALUE TO INSERT IN QUEUE !"<<endl;
		cin>>val;
		rear++;
		q[rear]=val;
	}
}
void deleteQ()
{
	if( front==-1)
	{
		cout<<"QUEUE UNDERFLOW !"<<endl;
		return;
	}
	else
	{
		cout<<"Element deleted from queue is : "<<q[front]<<endl;
		front++;
	}
}
void display()
{
	if(front == -1)
	{
		cout<<"QUEUE IS EMPTY !"<<endl;
	}
	else
	{
		cout<<"ELEMENTS ARE -> ";
		for(int i=front;i<=rear;i++)
		cout<<q[i]<<" ";
		cout<<endl;
	}
}
int main()
{
	int a;
	cout<<"------MENU------"<<endl;
	cout<<"1 -> INSERT  "<<endl;
	cout<<"2 -> DELETE  "<<endl;
	cout<<"3 -> DISPLAY "<<endl;
	cout<<"4 -> EXIT    "<<endl;
	cout<<"----------------"<<endl;
	cout<<"ENTRE UR CHOICE !!"<<endl;
	
	do{
		cin>>a;
		switch(a)
		{
			case 1:
				insert();
				break;
				case 2:
					deleteQ();
					break;
					case 3:
						display();
						break;
						case 4:
						    exit(0);
							break;
		}
		cout<<"ENTRE YOUR CHOICE AGAIN !"<<endl;
    }
	while(a!=4);
}

