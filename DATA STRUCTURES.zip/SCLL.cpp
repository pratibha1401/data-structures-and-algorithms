#include<iostream>
#include<math.h>
using namespace std;
struct node
{
	int data;
	int exp1;
	int exp2;
	int exp3;
	node *next;
};
class linklst
{
	node *start1;
	node *start2;
	public:
		linklst()
		{
			start1=NULL;
			start2=NULL;
		}
		void insertion1(int,int,int,int);
		void insertion2(int,int,int,int);
		void add();
		void display();
		void evaluate();
};
void linklst::insertion1(int d,int a,int b,int c)
{
	node *newnode=new node;
	node *newnoden=new node;
	newnoden->data=d;
	newnoden->exp1=a;
	newnoden->exp2=b;
	newnoden->exp3=c;
	newnoden->next=NULL;
	if(start1==NULL)
	{
		start1=newnoden;
	}
	else
	{
		newnode=start1;
		while(newnode->next!=NULL)
		{
			newnode=newnode->next;
		}
		newnode->next=newnoden;
	}
}
void linklst::insertion2(int d,int a,int b,int c)
{
	node *newnode=new node;
	node *newnoden=new node;
	newnoden->data=d;
	newnoden->exp1=a;
	newnoden->exp2=b;
	newnoden->exp3=c;
	newnoden->next=NULL;
	if(start2==NULL)
	{
		start2=newnoden;
	}
	else
	{
		newnode=start2;
		while(newnode->next!=NULL)
		{
			newnode=newnode->next;
		}
		newnode->next=newnoden;
	}
}
void linklst::display()
{
	node *current1=start1;
	node *current2=start2;
	if(start1!=NULL)
	{
	cout<<"\n\nPolynomial 1 -> ";
    cout<<current1->data<<" x^"<<current1->exp1<<" y^"<<current1->exp2<<" z^"<<current1->exp3;
    current1=current1->next;
	while(current1!=NULL)
	{
		cout<<" + "<<current1->data<<" x^"<<current1->exp1<<" y^"<<current1->exp2<<" z^"<<current1->exp3;
		current1=current1->next;
    }
    }
    if(start2!=NULL)
    {
    cout<<"\n\nPolynomial 2 -> ";
    cout<<current2->data<<" x^"<<current2->exp1<<" y^"<<current2->exp2<<" z^"<<current2->exp3;
    current2=current2->next;
	while(current2!=NULL)
	{
		cout<<" + "<<current2->data<<" x^"<<current2->exp1<<" y^"<<current2->exp2<<" z^"<<current2->exp3;
		current2=current2->next;	
    }
    }
}
void linklst::add()
{
	node *current1;
	node *current2=start2;
	node *current3;
	node *current4;
	node *current5;
	while(current2!=NULL)
	{
		current1=start1;
		while(current1!=NULL)
		{
			if((current1->exp1)==(current2->exp1) && (current1->exp2)==(current2->exp2) && (current1->exp3)==(current2->exp3))
			{
				current1->data = current1->data + current2->data;
				if(current2==start2)
				{
					current3=current2->next;
					start2=current3;
				}
				else
				{
				current3=current2->next;
				current4->next=current3;
			    }
			}
			
			current1=current1->next;
		}
		current4=current2;
		current2=current2->next;
	}
	current1=start1;
	current2=start2;
	current4=NULL;
	while(current2!=NULL)
	{
		current1=start1;
		while(current1!=NULL)
		{
			if(((current2->exp1)+(current2->exp2)+(current2->exp3))>=((current1->exp1)+(current1->exp2)+(current1->exp3)))
			{
			    if(current1==start1)
				{
					current5=current2;
					current3=current5->next;
					start2=current3;
					current5->next=current1;
					start1=current5;
					current2=start2;
				}
				else
				{
					current5=current2;
					current3=current5->next;
					start2=current3;
					current4->next=current5;
					current5->next=current1;
					current2=start2;
				}
			}
			current4=current1;
		    current1=current1->next;
	    }
    }
	node *current=start1;
	cout<<"\nResultant Polynomial -> ";
    cout<<current->data<<" x^"<<current->exp1<<" y^"<<current->exp2<<" z^"<<current->exp3;
    current=current->next;
	while(current!=NULL)
	{
		cout<<" + "<<current->data<<" x^"<<current->exp1<<" y^"<<current->exp2<<" z^"<<current->exp3;
		current=current->next;
    }	
}
void linklst::evaluate()
{
	cout<<"\nENTER VALUES OF X,Y AND Z: ";
	int p,q,r;
	cin>>p>>q>>r;
	node *t=new node();
	t=start1;
	int sum=0;
	while(t->next!=NULL)
	{
		sum=sum+((t->data)*(pow(p,t->exp1))*(pow(q,t->exp2))*(pow(r,t->exp3)));
		t=t->next;
	}
    sum=sum+((t->data)*(pow(p,t->exp1))*(pow(q,t->exp2))*(pow(r,t->exp3)));
    cout<<"\n     ANSWER IS: "<<sum;
	start1=NULL;
}
int main()
{
    linklst l;
    cout<<"-------------------------------------------POLYNOMIAL EVALUATION AND ADDITION-------------------------------------------\n\n";
	cout<<"				_______________________________________________________\n";
	cout<<"				|Press 1. Represent and Evaluate a Polynomial P(x,y,z)|\n";
	cout<<"				|Press 2. Find the sum of two Polynomials             |\n";
	cout<<"                                ```````````````````````````````````````````````````````\n";
    int q;
do{
	cout<<"\n    		ENTER THE CHOICE: ";
    cin>>q;
if(q==1)
{
	int m,a,b,c,d;
    cout<<"Enter Polynomial\n";
    cout<<"Enter no. of terms : ";
    cin>>m;
    cout<<"\n";
    for(int i=0;i<m;i++)
    {
        cout<<"Coefficient of "<<i+1<<" term : ";
        cin>>d;
        cout<<"Power of x : ";
        cin>>a;
        cout<<"Power of y : ";
        cin>>b;
        cout<<"Power of z : ";
        cin>>c;
        l.insertion1(d,a,b,c);
    }
	l.insertion1(d,a,b,c);
	l.display();
	l.evaluate();
}
if(q==2)
{
	int m,n,a,b,c,d;
    cout<<"Enter First Polynomial\n";
    cout<<"Enter no. of terms : ";
    cin>>m;
    cout<<"\n";
    for(int i=0;i<m;i++)
    {
        cout<<"Coefficient of "<<i+1<<" term : ";
        cin>>d;
        cout<<"Power of x : ";
        cin>>a;
        cout<<"Power of y : ";
        cin>>b;
        cout<<"Power of z : ";
        cin>>c;
        l.insertion1(d,a,b,c);
    }
    cout<<"\nEnter Second Polynomial \n";
    cout<<"Enter no. of terms : ";
    cin>>n;
    cout<<"\n";
    for(int i=0;i<n;i++)
    {
        cout<<"Coefficient of "<<i+1<<" term : ";
        cin>>d;
        cout<<"Power of x: ";
        cin>>a;
        cout<<"Power of y: ";
        cin>>b;
        cout<<"Power of z: ";
        cin>>c;
        l.insertion2(d,a,b,c);
    }
    l.display();
    l.add();
}	
}while(q!=3);
    
}
