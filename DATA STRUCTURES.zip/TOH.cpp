#include<iostream>
     using namespace std;
     int sn[4],sb[4],sa[4],se[4],sadd[4];
int add=3;
char beg='A',aux='B',end='C';
int n,top=-1;
int main()
{
	cout<<"enter the no. of disc ";
	cin>>n;
	cout<<"\n";
s1:
		{
		
	if(n==1)
	{
		cout<<"Put disc form tower: "<<beg<<" to "<<end<<endl;
		goto s5;
	}
}
	top=top+1;
	
	sn[top]=n;
	sb[top]=beg;
	sa[top]=aux;
	se[top]=end;
	sadd[top]=3;
	
	n=n-1;
	beg=beg;
	char t;
	t=aux;
	aux=end;
	end=t;
	goto s1;
	
	s3:
		{
			
			cout<<"Put disc form tower: "<<beg<<" to "<<end<<endl;
		}

	top=top+1;
	sn[top]=n;
	sb[top]=beg;
	sa[top]=aux;
	se[top]=end;
	sadd[top]=5;
	
	n=n-1;
	char t1;
	t1=beg;
	beg=aux;
	aux=t1;
	end=end;
	goto s1;
	
	s5:
		
		n=sn[top];
		beg=sb[top];
		aux=sa[top];
		end=se[top];
		add=sadd[top];
		top=top-1;
		if(add==3)
		{
		goto s3;
	}
		else if(add==5)
		goto s5;
}

