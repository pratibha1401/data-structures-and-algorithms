#include<iostream>
using namespace std;
int value, i, j, key, pos, temp, s[100], n;
void insert() //inserting element at start and end
{
	cout<<"\n Enter the position of the element to be inserted: \t";
	cin>>pos;
	if(pos<0 || pos>n)
	cout<<"enter within the limits of array size";
	else
	{
		cout<<"enter the element to be inserted: ";
		cin>>value;
		for(i=n;i>=pos;i--)
		{
			s[i+1]=s[i];
		}
		n++;
		s[pos] = value;
		cout<<"\n The inserted element is: "<<value;
	}
}
void del() //deleting element in array
{
	cout<<"\n Enter the position of the array where you want to delete: ";
	cin>>pos;
	if(pos<0||pos>n)
	cout<<"enter within the limits of array size";
	value= s[pos];
	for(i=pos;i<n-1;i++)
	{
		s[i]=s[i+1];
	}
	s[n] = NULL;
	n=n-1;
	cout<<"\n The deleted element is: "<<value;
}
void location() //searching element in an array
{
	cout<<"\n Enter the element to find its location \t";
	cin>>key;
	for(i=0;i<n;i++)
	{
		if(s[i]==key)
		{
			cout<<"\nThe element is present at position: "<<i+1;
			break;
		}
	}
	if (i==n)
	{
		cout<<"\nELEMENT CANNOT BE FOUND ";
	}
}
void display() //displaying array elments
{
	int i;
	cout<<"\n The array elements are: \n";
	for(i=0;i<n;i++)
	{
		cout<<s[i]<<"\t";
	}
}

int main()
{
	int choice,e;
	cout<<"ENTER ARRAY SIZE: \t";
	cin>>n;
	cout<<"\nEnter elements of the array: \n";
	for(int i=0; i<n; i++)
	{
		cin>>s[i];
	}
	do{
		cout<<"\n1. To insert element in the array \n";
		cout<<"\n2. To delete an element in the array \n";
		cout<<"\n3. To find the location of any element in the array \n";
		cout<<"\n4. To display the elements of the array \n";
		cout<<"\nEnter your choice: \t";
		cin>>choice;
		switch(choice)
		{
			case 1:
				insert();
				break;
			case 2:
				del();
				break;
				
			case 3:
				location();
				break;
			case 4:
				display();
				break;
			default:
				cout<<"\nINVALID  CHOICE\n";
				break;		
		}
		cout<<"\nTo continue enter 1 \t";
		cin>>e;
	}
	while(e=1);
	return 0;
}
