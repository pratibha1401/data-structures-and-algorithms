#include<iostream>
#include<stack>
using namespace std;
int x,top=-1;
void push(int stack[])
{
if(top==x-1)
cout<<"STACK OVERFLOW!\n";
else
{ int value;
    cout<<"Enter the value to be pushed : ";
cin>>value;
top=top+1;
stack[top]=value;
}
}
void pop(int stack[])
{
if(top==-1)
cout<<"STACK UNDERFLOW!\n";
else
{
cout<<"Deleted item is : "<<stack[top]<<"\n";
top=top-1;
}
}
int display(int stack[])
{
cout<<"Elements : \n";
for(int i=top;i>=0;i--)
cout<<stack[i]<<"\n";
}
int main()
{
char ch;
cout<<"Enter the size of stack : ";
cin>>x;
int stack[x];
int choice;
cout<<"Enter 1 to push\nEnter 2 to pop\nEnter 3 to display\n";
do{
   cin>>choice;
   switch(choice)
  {
   case 1:
   push(stack);
   break;
   case 2:
   pop(stack);
   break;
case 3:
display(stack);
break;
  }
cout<<"Do you want to continue (1/0) : ";
cin>>ch;
    }while(ch=='1');
}
