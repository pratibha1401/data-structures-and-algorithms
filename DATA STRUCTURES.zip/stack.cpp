#include<iostream>
using namespace std;
int stack[5],ch,top=-1,n=5;
void push(int);
void pop();
void display();
int main()
{
	do
	{
	
	cout<<endl<<"entre your choice : "<<endl;
	cout<<endl<<"1 -> to push an element : ";
	cout<<endl<<"2 -> to pop ana element : ";
	cout<<endl<<"3 -> to dislpay elements : ";
	cout<<endl<<"4 -> to exit : ";
	cin>>ch;
	switch(ch)
	{
		case 1:
			int e;
			cout<<endl<<"entre the element :  "<<endl;
			cin>>e;
			push(e);
			break;
			case 2:
				pop();
				break;
				case 3:
					cout<<endl<<"elements are : "<<endl;
					display();
					break;
					case 4:
						exit(0);
						break;
						default:
							cout<<endl<<"invalid choice : "<<endl;
		
	}cout<<"--------------------------------------------------------------------------------------------------------------";
}while(ch!=4);
}
void push(int e)
{
	if(top>n-1)
	cout<<endl<<"stack is overflow"<<endl;
	else
	{
		top++;
		stack[top]=e;
	}
}
void pop()
{
	if(top<=-1)
	cout<<endl<<"stack is underflow : "<<endl;
	else
	{
		cout<<endl<<"popped element is : "<<stack[top]<<endl;
		top--;
	}
}
void display()
{
	for( int i=top;i>=0;i--)
	{
		cout<<endl<<stack[i]<<" "<<endl;
	}
}

