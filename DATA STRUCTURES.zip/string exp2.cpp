#include<iostream>
#include<algorithm>
#include<string.h>
#define endl "\n"
using namespace std;

void findAndReplaceAll(std::string & data, std::string toSearch, std::string replaceStr)
{
	size_t pos = data.find(toSearch);
 
	while( pos != std::string::npos)
	{
		data.replace(pos, toSearch.size(), replaceStr);
		pos =data.find(toSearch, pos + replaceStr.size());
	}
}
int main()
{
	do{
	cout<<"\n\nCHOOSE AN OPTION: ";
	cout<<"\n\n1. Read string."<<endl;
	cout<<"2. Replace string with given pattern."<<endl;
	cout<<"3. Pattern matching."<<endl;
	cout<<"4. Remove all occurences of the given pattern"<<endl;
	cout<<"5. Exit"<<endl;
	int ch;
	cin>>ch;
	switch(ch)
	{
		case 1:
			{
		string s="";
	cout<<"\nENTER THE STRING: ";
	cin>>s;
		
		cout<<"The entered string is: "<<s;
		}
		break;
		case 2:
			{
			string s1="",s2="",s3="";
			cout<<"\nEnter a string:";
			cin>>s1;
			cout<<"Enter pattern to be found:";
			cin>>s3;
			cout<<"Enter pattern to be replaced with:";
            cin>>s2;
			
			findAndReplaceAll(s1, s2, s3);
			cout<<"REPLACED STRING IS: "<<s1;
		}
		break;
		case 3:
		{
		
			string str="",subs="";
			cout<<"Enter a string:";
			cin>>str;
			cout<<"Enter pattern to be found:";
			cin>>subs;
			int i,j,temp;
			for(i=0;str[i]!='\0';i++)
    		{
        		j=0;
        		if(str[i]==subs[j])
        		{
        		    temp=i+1;
        		    while(str[i]==subs[j])
            		{
                		i++;
               		 	j++;
            		}
 
            		if(subs[j]=='\0')
            		{
                		cout<<"The substring is present in given string at position "<<temp<<"\n";
                		exit(0);
            		}
           			 else
            		{
                		i=temp;
                		temp=0;
            		}
        		}
    		}
 		  if(temp==0)
        			cout<<"The substring is not present in given string\n";}
 		break;
		case 4:
			{
		
string str="";
string str1="";
string s2 ="";
string s1 = "";
  
  {
  	cout<<"\nenter string: ";
  cin>>str;
  cout<<"enter pattern: ";
  cin>>s1;
    bool flag = false; 
    for (int i = 0; i < str.length(); i++) { 
        if (str.substr(i, s1.length()) == s1) { 
            cout << i << " "; 
            flag = true; 
        } 
    }  
	if (flag == false) 
        cout << "NONE"; 
        	
} 


  cout<<"\nenter pattern to be replaced: ";
  cin>>s2;
  
  findAndReplaceAll(str,s1,s2);
  cout<<"string is: "<<str;
			}
			
		break;
		default:cout<<"Invaid choice"<<endl;
		break;
	}
	}while(true);
}

