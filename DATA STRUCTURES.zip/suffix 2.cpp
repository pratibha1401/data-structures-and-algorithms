#include<iostream>
  #include<ctype.h>
  #include<math.h>
  using namespace std;
  # define MAXSTACK 100         
  char stack[MAXSTACK];
  int top = -1;   
  void push(int item)
   {
	 if(top >= MAXSTACK -1)
	 {
		 cout<<"stack over flow";
		 return;
	 }
	 else
	 {
		 top = top + 1 ;
		 stack[top]= item;
	 }
 }
int pop()
 {
	 int item;
	 if(top <0)
	 {
		cout<<"stack under flow";
	 }
	 else
	 {
		 item = stack[top];
		 top = top - 1;
		 return item;
	 }
 } 
int prec(char c) 
{ 
    if(c=='^') 
    return 3; 
    else if(c=='*'||c=='/') 
    return 2; 
    else if(c=='+'||c=='-') 
    return 1; 
    else
    return -1; 
} 
void infixToPostfix(string s) 
{  
    push('N'); 
    int l = s.length(); 
    string ns,o;
	int x=0; 
    for(int i=0;i<l;i++) 
    {  
        cout<<s[i];
        if(s[i]>='0'&&s[i]<='9') 
		ns+=s[i];
        else if(s[i]=='(') 
        push('(');  
        else if(s[i]==')') 
        { 
            while(stack[top]!='N'&&stack[top]!='(') 
            { 
                char c=stack[top]; 
                pop(); 
                ns+=c; 
            } 
            if(stack[top]=='(') 
            { 
                char c=stack[top]; 
                pop(); 
            } 
        } 
        else{ 
            while(stack[top]!='N'&&prec(s[i])<=prec(stack[top])) 
            { 
                char c=stack[top]; 
                pop(); 
                ns+= c; 
            } 
            push(s[i]); 
        } 
        int j=1;
        cout<<"\t\t";
        while(j<=top)
        {
        	cout<<stack[j];
        	j++;
		}
		cout<<"\t\t";
		cout<<ns;
		cout<<"\n";
        
    } 
    while(stack[top]!='N') 
    { 
        char c=stack[top]; 
        pop(); 
        ns+=c; 
        int j=1;
        while(j<=top)
        {
        	cout<<stack[j];
        	j++;
		}
		cout<<ns;
		cout<<"\n";
    } 
    cout<<"\nPostfix Expresion : "<<ns<<"\n\n";
    int i;
    char ch;
	int val;
	int A, B ;
	for (i = 0 ; ns[i] != '\0'; i++)
	{    
		ch = ns[i];
		if (isdigit(ch))
		{
			cout<<ch<<": is inserted\n";
			push(ch - '0');
		}
		else if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch =='^' || ch == '%' )
		{
		    A = pop();
			cout<<A<<": is poped out\n";
			B = pop();
			cout<<B<<": is poped out\n";
            switch (ch)
			{
				case '*':
				val = B * A;
				cout<<B<<"*"<<A<<"="<<val<<": is inserted\n\n ";
				break;
				
				case '/':
				val = B / A;
				cout<<B<<"/"<<A<<"="<<val<<": is inserted \n\n";
				break;
				
				case '+':
				val = B + A;
				cout<<B<<"+"<<A<<"="<<val<<": is inserted \n\n";
				break;
				
				case '-':
				val = B - A;
				cout<<B<<"-"<<A<<"="<<val<<": is inserted \n\n";
				break;
				
			            case '^':
				val = pow(B,A);
				cout<<B<<"^"<<A<<"="<<val<<": is inserted \n\n";
			break;
				
				case '%':
			val = B % A;
				cout<<B<<"%"<<A<<"="<<val<<": is inserted \n\n";
				break;
			}
            push(val);
		}
	}
	cout<< "Result of expression evaluation : "<<pop() ;
} 
int main() 
{ 
    string exp;
    cout<<"Enter the  Infix expresion : ";
    cin>>exp;
    infixToPostfix(exp); 
 }

